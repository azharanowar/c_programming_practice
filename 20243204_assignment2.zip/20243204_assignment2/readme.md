Hello Professor,
I am Md Anwar Hosen and my student ID is 20243204. I have completed the 5 tasks of the assignment myself according to my understanding of the questions. I tried my best and after coding I run each and every code and It's working fine from my end. Please let me know if there is anything else I need to do. It was really a good exercise of coding and mind. Looking ahead to learn more from next.

Thank you very much professor for your time.

Yours sincerely
Anwar