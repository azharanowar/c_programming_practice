Hello Professor,
I am Md Anwar Hosen and my student ID is 20243204. Here is my assignment three. I have tried to solve every questions according to my understanding. Everything is working fine from my end. Please let me know if there is anything wrong I did. Looking ahead to learn more from you.

Thank you very much professor for your time.

Yours sincerely
Anwar